import React, { useRef } from 'react';
import { Building2, Users, Briefcase, Phone, Mail, MapPin, Calculator } from 'lucide-react';
import ContactForm from './components/ContactForm';
import Navbar from './components/Navbar';
import ServicesSection from './components/ServicesSection';
import TeamSection from './components/TeamSection';

function App() {
  const contactRef = useRef<HTMLDivElement>(null);

  const scrollToContact = () => {
    contactRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white">
      <Navbar onContactClick={scrollToContact} />
      
      {/* Hero Section */}
      <section className="relative h-screen">
        <div className="absolute inset-0">
          <img
            src="https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80"
            alt="Office"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-black bg-opacity-50"></div>
        </div>
        
        <div className="relative h-full flex items-center px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto text-center">
            <h1 className="text-4xl sm:text-6xl font-bold text-white mb-6">
              MEIO SÉCULO DE EXPERIÊNCIA
            </h1>
            <p className="text-xl sm:text-2xl text-white mb-8 max-w-3xl mx-auto">
              Prestando serviços de contabilidade com qualidade e ótimos resultados para nossos clientes
            </p>
            <button
              onClick={scrollToContact}
              className="bg-blue-600 text-white px-8 py-3 rounded-lg text-lg font-semibold hover:bg-blue-700 transition duration-300"
            >
              Fale Conosco
            </button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="sobre" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Quem Somos</h2>
            <div className="w-20 h-1 bg-blue-600 mx-auto"></div>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
            <div>
              <img
                src="https://images.unsplash.com/photo-1600880292203-757bb62b4baf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1950&q=80"
                alt="Nossa Empresa"
                className="rounded-lg shadow-xl"
              />
            </div>
            <div>
              <h3 className="text-2xl font-semibold mb-4">Nossa História</h3>
              <p className="text-gray-600 mb-6">
                Com mais de 50 anos de experiência no mercado, nossa empresa se destaca pela excelência
                em serviços contábeis e compromisso com o sucesso de nossos clientes.
              </p>
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <Building2 className="w-6 h-6 text-blue-600" />
                  </div>
                  <div className="ml-4">
                    <h4 className="font-semibold">Missão</h4>
                    <p className="text-gray-600">Oferecer soluções contábeis de excelência</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <Users className="w-6 h-6 text-blue-600" />
                  </div>
                  <div className="ml-4">
                    <h4 className="font-semibold">Valores</h4>
                    <p className="text-gray-600">Ética, transparência e comprometimento</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <ServicesSection />
      <TeamSection />

      {/* Contact Section */}
      <section ref={contactRef} id="contato" className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Fale Conosco</h2>
            <div className="w-20 h-1 bg-blue-600 mx-auto"></div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <div>
              <h3 className="text-2xl font-semibold mb-6">Informações de Contato</h3>
              <div className="space-y-6">
                <div className="flex items-center">
                  <Phone className="w-6 h-6 text-blue-600" />
                  <span className="ml-4 text-gray-600">(18) 1234-5678</span>
                </div>
                <div className="flex items-center">
                  <Mail className="w-6 h-6 text-blue-600" />
                  <span className="ml-4 text-gray-600">contato@contabilidade.com.br</span>
                </div>
                <div className="flex items-center">
                  <MapPin className="w-6 h-6 text-blue-600" />
                  <span className="ml-4 text-gray-600">
                    Rua Example, 123 - Centro<br />
                    Presidente Prudente - SP
                  </span>
                </div>
              </div>
            </div>
            
            <ContactForm />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <p>&copy; 2024 Contabilidade. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}

export default App;