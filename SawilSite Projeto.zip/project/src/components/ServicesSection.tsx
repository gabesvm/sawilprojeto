import React from 'react';
import { Calculator, FileText, PieChart, Users, Building, Briefcase } from 'lucide-react';

const services = [
  {
    icon: Calculator,
    title: 'Contabilidade Geral',
    description: 'Serviços completos de contabilidade para empresas de todos os portes'
  },
  {
    icon: FileText,
    title: 'Departamento Fiscal',
    description: 'Gestão fiscal e tributária para otimizar seus resultados'
  },
  {
    icon: Users,
    title: 'Departamento Pessoal',
    description: 'Administração completa da folha de pagamento e recursos humanos'
  },
  {
    icon: Building,
    title: 'Abertura de Empresas',
    description: 'Assessoria completa para abertura e regularização de empresas'
  },
  {
    icon: PieChart,
    title: 'Planejamento Tributário',
    description: 'Estratégias para redução legal da carga tributária'
  },
  {
    icon: Briefcase,
    title: 'Consultoria Empresarial',
    description: 'Orientação especializada para tomada de decisões'
  }
];

const ServicesSection = () => {
  return (
    <section id="servicos" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold text-gray-900 mb-4">Nossos Serviços</h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto"></div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div
              key={index}
              className="bg-white p-6 rounded-lg shadow-lg hover:shadow-xl transition duration-300"
            >
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
                <service.icon className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="text-xl font-semibold mb-2">{service.title}</h3>
              <p className="text-gray-600">{service.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ServicesSection;